package br.com.acme.service4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
